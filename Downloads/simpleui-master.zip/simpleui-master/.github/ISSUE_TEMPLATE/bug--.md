---
name: bug报告
about: Create a bug report to help us improve
title: ''
labels: bug
assignees: ''

---

**bug描述**
* *Bug description * * 

简单的描述下遇到的bug：
Briefly describe the bugs encountered:


**重现步骤**
** repeat step **
1.
2.
3.

**环境**
** environment**

1.Operating System：
(Windows/Linux/MacOS)....

2.Python Version：

3.Django Version：

4.SimpleUI Version：


**Description**
