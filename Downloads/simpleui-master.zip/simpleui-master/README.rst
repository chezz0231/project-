**django-simpleui**

github:

https://github.com/newpanjing/simpleui

gitee:

https://gitee.com/tompeppa/simpleui


QQ群：
786576510
