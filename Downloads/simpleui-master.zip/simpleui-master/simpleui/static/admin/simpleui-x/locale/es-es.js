var Lanuages = {
    "Refresh": "Refrescar",
    "Close current": "Cerrar actual",
    "Close other": "Cerrar otro",
    "Close all": "Cerrar todos",
    "Open in a new page": "Abrir en nueva página",
    "Change theme": "Cambiar tema",
    "Default": "Por defecto",
    "Servers": "Servidores",
    "Application information": "Información de la aplicación",
    "Home page": "Página de inicio",
    "Report issue": "Reportar un error",

    "Select": "Seleccionar",
    "Selected": "Seleccionado",


    "Purple": "Púrpura",
    "Gray": "Gris",
    "Dark green": "Verde oscuro",
    "Orange": "Naranja",
    "Black": "Negro",
    "Green": "Verde",
    "Light": "Claro",

    "Number": "Número",
    "Theme name": "Nombre del tema",
    "Action": "Acción",

    "ConfirmYes": "Confirmar",
    "ConfirmNo": "Cancelar",
    "Tips": "Info",
    "Are you sure you want them all closed": "¿Seguro que desea cerrar todo?",

    "to": "a",
    "Quick navigation": "Acceso rápido",
    "Go back": 'Atrás',

    'Set font size': 'Seleccionar tamaño de fuente',
    'Reset': 'Resetear',
    'Are you sure you want to delete the selected?': '¿Seguro que desea borrar lo seleccionado?',
    'Please select at least one option!': '¡Elige al menos una opción!',
    'Please enter your username or password!': 'Introduce tu correo electrónico y contraseña'
}
