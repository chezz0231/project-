var Lanuages = {
    "Refresh": "Recarregar",
    "Close current": "Fechar atual",
    "Close other": "Fechar outro",
    "Close all": "Fechar todos",
    "Open in a new page": "Abrir uma nova página",
    "Change theme": "Mudar o tema",
    "Default": "Padrão",
    "Servers": "Servidores",
    "Application information": "Informações da aplicação",
    "Home page": "Pagina inicial",
    "Report issue": "Reportar um problema",

    "Select": "Selecionar",
    "Selected": "Selecionado",


    "Purple": "Roxo",
    "Gray": "Cinza",
    "Dark green": "Verde Escuro",
    "Orange": "Laranjado",
    "Black": "Preta",
    "Green": "Verde",
    "Light": "Claro",

    "Number": "Número",
    "Theme name": "Nome do tema",
    "Action": "Ação",

    "ConfirmYes": "ConfirmarSIM",
    "ConfirmNo": "ConfirmarNão",
    "Tips": "Dicas",
    "Are you sure you want them all closed": "Você tem certeza que quer fechar tudo?",

    "to": "para",
    "Quick navigation": "Navegação rápida",
    "Go back": 'Voltar',

    'Set font size': 'Mudar tamanho da fonte',
    'Reset': 'Reiniciar',
    'Are you sure you want to delete the selected?': 'Tem certeza que quer apagar os selecionados?'
}